盲潮 Blind Tide - Windows x86_64 发布版

双击 blind-tide.exe 运行。可选麦克风；不插麦克风请点「无麦克风启动（键盘声呐）」。
路径请不要包含空格。

GODOT_LICENSE.txt 是引擎许可（MIT）。
