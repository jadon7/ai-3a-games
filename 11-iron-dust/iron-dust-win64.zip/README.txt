铁尘 IRON DUST - Windows x86_64 发布版

双击 iron-dust.exe 运行。需要支持 D3D12/Vulkan 的显卡。
路径请不要包含空格。

GODOT_LICENSE.txt 是引擎许可（MIT），AUDIO_CREDITS.md / TEXTURE_CREDITS.md 是素材署名。
